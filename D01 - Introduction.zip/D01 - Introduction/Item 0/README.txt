LOPD

To notify a security breach, ACME Madrug� uses our message exchange service. Administrators
 can notify it with URL since /boxes/list.do. This will send a message to all the users of the
 system.

To export personal data, users must go to URL administrator/administrator/show.do,
 brotherhood/brotherhood/show.do or member/member/show.do, depending on the kind of user.
 They have to right click anywhere, select "Save page as..." and click "Save".

To remove personal data, users must go to URL administrator/administrator/edit.do,
 brotherhood/brotherhood/edit.do or member/member/edit.do, depending on the kind of user. 
 They have to click "Leave the system" and all their personal data will be depersonalized.

ENROLEMENTS

Members can propose enrolements. Enrolements can be accepted or refused by a brotherhood.

REQUESTS

A member can only request to march on a procession which departure date is after actual date
 to avoid requests to processions that already marched.

FLOAT / PROCESSIONS

When a procession is saved in Draft mode, floats can be added and deleted. If a procession
isn't in Draft mode, floats that become to this procession can't be deleted. Processions can
be edited or deleted as long as they are not in Draft mode.